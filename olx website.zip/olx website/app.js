function clickmore(){
    var a=document.getElementById("div1")
    var b=document.getElementById("div2")
    b.innerHTML=a.innerHTML
    console.log("sadsadsa")
}

// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}